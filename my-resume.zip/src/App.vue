<template>
  <div class="container column">
    <IsResumeForm @block-added="addBlock"/>
    <IsResumeView :blocks="blocks"/>
  </div>
  <div class="container">
    <IsLoader v-if="loading"/>
    <IsResumeComments v-else :comments="comments" @add-comments="AddComments" />
  </div>
</template>

<script>
import axios from 'axios'
import IsResumeForm from './components/IsResumeForm'
import IsResumeView from './components/IsResumeView'
import IsResumeComments from './components/IsResumeComments'
import IsLoader from './components/IsLoader'

export default {
  components: {
    IsResumeForm,
    IsResumeView,
    IsResumeComments,
    IsLoader
  },
  data() {
    return {
      blocks: [],
      comments: [],
      loading: false
    }
  },
  async created() {
    try {
      const response = await axios.get(`https://ark-vip-default-rtdb.firebaseio.com/resume.json`)
      this.blocks = Object.keys(response.data).map(key => {
        return {
          id: key,
          ...response.data[key],
        }
      })
      // console.log(this.blocks)
    } catch (error) {
      // console.error(error)
    }
  },
  // created() {
  //   return new Promise((resolve, reject) => {
  //     axios.get('https://ark-vip-default-rtdb.firebaseio.com/resume.json')
  //         .then(response => {
  //           this.blocks = Object.keys(response.data).map(key => {
  //             return {
  //               id: key,
  //               ...response.data[key],
  //             }
  //           })
  //         })
  //         .then(response => resolve(response))
  //         .catch(error => reject(error))
  //   })
  // },
  methods: {
    async AddComments() {
      this.loading = true
      const response = await axios.get('https://ark-vip-default-rtdb.firebaseio.com/comments/-NI7iG32L51cfqJnu-Ii.json')
      this.comments = await response.data
      this.loading = false
    },
    addBlock(resumeData) {
      this.blocks.push(resumeData)
    }
  }
}
</script>
