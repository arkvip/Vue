<template>
  <p>{{ this.$attrs.value }}</p>
</template>