<template>
  <h2>{{$attrs.value}}</h2>
</template>