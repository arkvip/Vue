<template>
  <div class="avatar">
    <img :src="$attrs.value">
  </div>
</template>

<style scoped>

</style>