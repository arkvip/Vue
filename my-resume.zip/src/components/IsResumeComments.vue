<template>
  <div class="card" v-if="comments.length">
    <h2>Комментарии</h2>
    <ul class="list">
      <li class="list-item" v-for="comment in comments" :key="comment.id" >
        <div>
          <h2><strong>{{comment.name}}</strong></h2>
          <small>{{comment.body}}</small>
          <h4>{{comment.email}}</h4>
        </div>
      </li>
    </ul>
  </div>
  <p v-else>
    <button class="btn primary" @click="$emit('add-comments', 12345)">Загрузить комментарии!</button>
  </p>
</template>

<script>
export default {
  props: {
    comments: {type: Array, default: null, required: false}
  },
  // emits: ['add-comments'],
  emits: {
    'add-comments'(num) {
      if (num) {
        return true
      }
      console.warn('No data')
      return false
    }
  }
}
</script>

<style scoped>

</style>