<template>
  <div class="loader"></div>
</template>
