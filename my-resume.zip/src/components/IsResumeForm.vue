<template>
  <form class="card card-w30" @submit.prevent="onSubmit">
    <div class="form-control">
      <label for="type">Тип блока</label>
      <select id="type" v-model="type">
      <option v-for="option in options" :key="option.type" :value="option.type">
          {{ option.value }}
      </option>
      </select>
    </div>
    <div class="form-control">
      <label for="value">Значение</label>
      <textarea v-model="value" id="value" rows="3"></textarea>
    </div>
    <button class="btn primary" :disabled="!isDisabled">Добавить</button>
  </form>
</template>

<script>
import axios from 'axios'

export default {
  data() {
    return {
      type: 'title',
      value: '',
      options: [
        { type: 'title', value: 'Заголовок' },
        { type: 'subtitle', value: 'Подзаголовок' },
        { type: 'avatar', value: 'Аватар' },
        { type: 'description', value: 'Описание' }
      ]
    }
  },
  computed: {
    isDisabled() {
      return this.value.length > 3
    }
  },
  methods: {
    async onSubmit() {
      let resumeData = {
        type: this.type,
        value: this.value,
        id:  Date.now()
      }
      this.$emit('block-added', resumeData)

      await axios.post(`https://ark-vip-default-rtdb.firebaseio.com/resume.json`,
          resumeData
      )
      this.value = ''
      this.type = 'title'
    },

    // onSubmit() {
    //   let resumeData = {
    //     type: this.type,
    //     value: this.value,
    //     id:  Date.now()
    //   }
    //   this.$emit('block-added', resumeData)
    //   // this.type = null
    //   // this.value = null
    //   // this.id = null
    //
    //   return new Promise((resolve, reject) => {
    //     axios.post(`https://ark-vip-default-rtdb.firebaseio.com/resume.json`, resumeData)
    //         .then(response => resolve(response))
    //         .catch(error => reject(error))
    //     this.value = ''
    //     this.type = 'title'
    //   })
    // }
  },
  emits: {
    'block-added'(resumeData) {
      if (resumeData) {
        return true
      }
      console.warn('No data')
      return false
    }
}
}
</script>

<style scoped>

</style>