<template>
  <div class="card card-w70">
    <template v-if="blocks.length">
      <component v-for="block in blocks"
          :key="block.id"
          :is="'is-block-' + block.type"
          v-bind="{value: block.value}"
      ></component>
    </template>
    <h3 v-else>Добавьте первый блок, чтобы увидеть результат</h3>
  </div>
</template>

<script>
import IsBlockTitle from './blocks/IsBlockTitle'
import IsBlockSubtitle from './blocks/IsBlockSubtitle'
import IsBlockAvatar from './blocks/IsBlockAvatar'
import IsBlockDescription from './blocks/IsBlockDescription.vue'

export default {

  // data() {
  //   return {}
  // },

  // computed: {},

  components: {
    IsBlockTitle,
    IsBlockSubtitle,
    IsBlockAvatar,
    IsBlockDescription

  },
  props: {
    blocks: {type: Array, default: null, required: false}
  },

}
</script>